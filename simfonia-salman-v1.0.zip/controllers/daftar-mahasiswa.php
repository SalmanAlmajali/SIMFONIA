<?php

    checkSession();

    $title = "Daftar Mahasiswa";

    require './views/daftar-mahasiswa.php';