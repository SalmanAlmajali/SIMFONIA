<?php
    checkSession();

    $title = "Dashboard";

    $name = $_SESSION['name'];

    require './views/dashboard.php';