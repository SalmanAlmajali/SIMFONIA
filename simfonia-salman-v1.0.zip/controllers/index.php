<?php
    session_start();
    
    if(!empty($_SESSION['isLogin'])) {
        header('location: /dashboard');
    }

    $title = "Log In | Mahasiswa";

    require './views/index.php';