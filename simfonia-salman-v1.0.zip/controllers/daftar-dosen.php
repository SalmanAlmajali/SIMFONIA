<?php

    checkSession();

    $title = "Daftar Dosen";

    require './views/daftar-dosen.php';