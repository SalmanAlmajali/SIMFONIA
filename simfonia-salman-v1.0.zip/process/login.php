<?php
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/users.json';
    $users = array();

    if(file_exists($filename)) {
        $users = json_decode(file_get_contents($filename), true);

        // Mengecek kesamaan data yang dinput dan data yang tersimpan di dalam file
        for($i = 0; $i < count($users); $i++) {
            if($users[$i]['username'] === $username && $users[$i]['password'] === $password) {

                session_start();
                
                $_SESSION['username'] = $users[$i]['username'];
                $_SESSION['name'] = $users[$i]['name'];
                $_SESSION['email'] = $users[$i]['email'];
                $_SESSION['role'] = $users[$i]['role'];
                $_SESSION['tahunAkademik'] = $users[$i]['tahunAkademik'];
                $_SESSION['isLogin'] = true;

                // Return pesan sukses
                $response = array('success' => true);

                echo json_encode($response);
                die();

            } else {
                // Return pesan error
                $response = array('success' => false);

                echo json_encode($response);
                die();
            }
        }
    }
