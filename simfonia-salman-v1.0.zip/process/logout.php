<?php

    // inisiasi session
    session_start();

    // menghapus semua variabel session
    session_unset();

    // menghapus session
    session_destroy();

    // Return pesan sukses
    $response = array('success' => true);

    echo json_encode($response);