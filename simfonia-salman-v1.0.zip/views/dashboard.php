<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">
            
                <?php require 'partials/dashboard_sidebar.php'; ?>

                <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                    <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white"><?= $name ?></h1>
                </div>
            </div>
        </main>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>
</body>
</html>