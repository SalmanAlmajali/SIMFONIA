<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    $(document).ready(function() {
        $('#logout').click(function(e) {
            e.preventDefault()

            Swal.fire({
                icon: 'question',
                status: 'question',
                title: "Logout",
                text: "Are you sure?",
                showCancelButton: true,
            }).then((res) => {
                if(res.isConfirmed) {
                    $.ajax({
                        url: "process/logout.php",
                        type: "GET",
                        success: function(res) {
                            // console.log(res);
                            var resParse = JSON.parse(res)
                            if(resParse.success) {
                                location.replace('/')
                            }
                        },
                        error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        })

        var isClicked = false

        $('#user-menu-button').click(function(e) {
            e.preventDefault()

            isClicked = !isClicked
            
            if(isClicked) {
                $('#user-menu').removeClass('hidden')
            } else {
                $('#user-menu').addClass('hidden')
            }

        })
    })
</script>