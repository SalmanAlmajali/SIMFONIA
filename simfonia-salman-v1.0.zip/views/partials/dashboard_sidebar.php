<div class="w-[20rem] hidden bg-white px-4 py-6 shadow-lg rounded-lg flex-col gap-y-4 md:flex">
    <a href="/dashboard" class="<?= urlIs('/dashboard') ? "bg-[#0059DB]" : "bg-slate-500" ?> text-white p-2 rounded-lg text-sm font-medium">Dashboard</a>
    <!-- <a href="/data-nilai" class="<?= urlIs('/data-nilai') ? "bg-[#0059DB]" : "bg-slate-500" ?> p-2 rounded-lg text-white text-sm font-medium">Data Nilai</a> -->
    <?php
        if($_SESSION['role'] == 'Admin'):
            if(urlIs('/mata-kuliah')) {
                echo '<a href="/mata-kuliah" class="bg-[#0059DB] p-2 rounded-lg text-white text-sm font-medium">Mata Kuliah</a>';
            } else {
                echo '<a href="/mata-kuliah" class="bg-slate-500 p-2 rounded-lg text-white text-sm font-medium">Mata Kuliah</a>';
            }

            if(urlIs('/daftar-dosen')) {
                echo '<a href="/daftar-dosen" class="bg-[#0059DB] p-2 rounded-lg text-white text-sm font-medium">Daftar Dosen</a>';
            } else {
                echo '<a href="/daftar-dosen" class="bg-slate-500 p-2 rounded-lg text-white text-sm font-medium">Daftar Dosen</a>';
            }
            
            if(urlIs('/daftar-mahasiswa')) {
                echo '<a href="/daftar-mahasiswa" class="bg-[#0059DB] p-2 rounded-lg text-white text-sm font-medium">Daftar Mahasiswa</a>';
            } else {
                echo '<a href="/daftar-mahasiswa" class="bg-slate-500 p-2 rounded-lg text-white text-sm font-medium">Daftar Mahasiswa</a>';
            }
            
        endif
    ?>
</div>