<?php
    require 'function.php';

    require 'router.php';