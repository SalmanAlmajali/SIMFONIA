<?php

    checkSession();

    // Membaca data yang tersedia dari file JSON
    $filename = './data/matkuls.json';
    $matkuls = array();
    $matkul = array();

    $fileUsers = './data/users.json';
    $users = array();
    $filteredUsers = array();
    
    $fileNilais = './data/nilais.json';
    $nilais = array();

    if(file_exists($filename) && file_exists($fileUsers) && file_exists($fileNilais)) {
        $matkuls = json_decode(file_get_contents($filename), true);

        for ($i=0; $i < count($matkuls); $i++) { 
            if($_SESSION['role'] === 'Dosen' && $matkuls[$i]['dosenPengajar'] === $_SESSION['username']) {

                $matkul[$i] = [
                    "MataKuliah" => $matkuls[$i],
                    'Dosen' => $_SESSION['name']
                ];
            }
        }

        $users = json_decode(file_get_contents($fileUsers), true);

        for ($i=0; $i < count($users); $i++) { 
            if($users[$i]['role'] === "Mahasiswa") {
                $filteredUsers[$i] = $users[$i];
            }
        }
    }

    $title = "Mata Kuliah | {$_SESSION['name']}";

    require './views/dosen-mata-kuliah.php';