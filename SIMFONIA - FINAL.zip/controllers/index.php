<?php
    session_start();
    
    if(!empty($_SESSION['isLogin'])) {
        header('location: /dashboard');
    }

    $title = "Log In";

    require './views/index.php';