<?php require 'partials/dashboard_head.php'; ?>

<?php

    $data = file_get_contents('data/nilais.json');
    $data = json_decode($data, true);
    
    $matkuls = file_get_contents('data/matkuls.json');
    $matkuls = json_decode($matkuls, true);
    
    $dosens = file_get_contents('data/users.json');
    $dosens = json_decode($dosens, true);
    

// Kode sebelumnya...

// Variabel untuk menyimpan HTML tabel
$tableContent = '';

// Loop foreach untuk mengisi data ke dalam tabel
foreach ($data as $item) {
    if ($item['namaMahasiswa'] == $username) {
        $namaMK = $item['namaMK'];
        foreach ($matkuls as $matkul) {
            if ($matkul['namaMK'] == $namaMK) {
                // Kode HTML untuk setiap baris data
                $nilaiAkhir = ($item['nilaiKehadiran']*0.1)+($item['nilaiTugas']*0.2)+($item['nilaiUTS']*0.3)+($item['nilaiUAS']*0.4);
                $angkaMutu = ($nilaiAkhir/100)*4;
                if($nilaiAkhir >= 85) {
                    $angkaMutu = '4';
                } elseif($nilaiAkhir >= 70) {
                    $angkaMutu = '3';
                } elseif($nilaiAkhir >= 60) {
                    $angkaMutu = '2';
                } elseif($nilaiAkhir >= 50) {
                    $angkaMutu = '1';
                } elseif($nilaiAkhir < 50) {
                    $angkaMutu = '0';
                }
                
                $hurufMutu ='';
                $sks = (int)'';
                $totalMutu = (int)'';
                
                if ($angkaMutu >= 3.5) {
                    $hurufMutu = 'A';
                } elseif ($angkaMutu >= 3.0) {
                    $hurufMutu = 'B';
                } elseif ($angkaMutu >= 2.75) {
                    $hurufMutu = 'C';
                } elseif ($angkaMutu >= 2.0) {
                    $hurufMutu = 'D';
                } elseif ($angkaMutu >= 0) {
                    $hurufMutu = 'E';
                }
                
                $sks += $matkul['sks']; // Menambahkan nilai UAS ke total
                $mutu = $matkul['sks'] * $angkaMutu;
                $totalMutu += $mutu;
                $ips = 0; // Variabel untuk menyimpan IPK
                if ($totalMutu > 0) {
                    $ips = $totalMutu / $sks; // Menghitung IPK dengan rata-rata nilai UAS
                    
                }
                $tableContent .= '
                <tr>
                    <td>' . $matkul['kodeMK'] . '</td>
                    <td>' . $item['namaMK'] . '</td>
                    <td>' . $matkul['sks'] . '</td>
                    <td>' . $item['nilaiKehadiran'] . '</td>
                    <td>' . $item['nilaiTugas'] . '</td>
                    <td>' . $item['nilaiUTS'] . '</td>
                    <td>' . $item['nilaiUAS'] . '</td>
                    <td>' . $nilaiAkhir . '</td>
                    <td>' . $angkaMutu . '</td>
                    <td>' . $hurufMutu . '</td>
                    <td>' . $mutu . '</td>
                </tr>
                <tr>';
            }
        }
    }
}

// Jika parameter generate_pdf diterima
if (isset($_GET['generate_pdf'])) {
    // Menghasilkan HTML untuk tabel
    $html = '
    <!DOCTYPE html>
    <html>
    <head>

        <style>
            table.customTable {
            width: 100%;
            background-color: #FFFFFF;
            border-collapse: collapse;
            border-width: 2px;
            border-color: #000000;
            border-style: solid;
            color: #000000;
            }

            table.customTable td, table.customTable th {
            border-width: 2px;
            border-color: #000000;
            border-style: solid;
            padding: 5px;
            }


        </style>

    </head>
    <body>
        <table>
            <tr>
                <td style="padding:10px;"><img src="https://tautanku.id/asset/img/icon.png" height="80px"></td>
                <td><p style="font-weight:bold;text-align:center;"> SIMFONIA<br>Sistem Informasi Nilai Akademik</p>Jl. Belitung No.7, Merdeka, Kec. Sumur Bandung, Kota Bandung, Jawa Barat 40113</td>
            </tr>
        </table>
        <div style="border-bottom-style: double;margin-top:10px;"></div><br>
            <h2 style="font-weight:bold;text-align:center;">Daftar Nilai Mahasiswa</H2>
            <table>
                <tr>
                    <th style="text-align:left;margin-bottom: 4px;">Nama Mahasiswa</th>
                    <td style="text-align:left;">: '.$name.'</td>
                </tr>
                <tr>
                    <th style="text-align:left;margin-bottom: 4px;">NIM</th>
                    <td style="text-align:left;margin-bottom: 4px;">: '.$username.'</td>
                </tr>
                <tr>
                    <th style="text-align:left;margin-bottom: 4px;">Tahun Akademik</th>
                    <td style="text-align:left;margin-bottom: 4px;">: '.$_SESSION['tahunAkademik'].'</td>
                </tr>
            </table>
            <br>
            <!-- Tabel dan informasi mahasiswa -->
            <table class="customTable">
                <thead>
                    <tr>
                        <th>Kode MK</th>
                        <th>Nama MK</th>
                        <th>Jumlah SKS</th>
                        <th>Nilai Absensi</th>
                        <th>Nilai Tugas</th>
                        <th>Nilai UTS</th>
                        <th>Nilai UAS</th>
                        <th>Nilai Akhir</th>
                        <th>Angka Mutu</th>
                        <th>Huruf Mutu</th>
                        <th>Mutu</th>
                    </tr>
                </thead>
                <tbody>
                    ' . $tableContent . '
                    <tr>
                        <td class="border border-gray-300 px-4 py-2 text-bold" colspan="10" style="font-weight: bold;">Indeks Prestasi Semester (IPS)</td>
                        <td class="border border-gray-300 px-4 py-2">' . number_format($ips, 2) . '</td>
                    </tr>
                </tbody>
            </table>
    </body>
    </html>
    ';

    // Import kelas DOMPDF
    require_once 'dompdf/autoload.inc.php';

    // Menginisialisasi DOMPDF
    $dompdf = new Dompdf\Dompdf();

    // Memasukkan HTML ke DOMPDF
    $dompdf->loadHtml($html);

    // Mengatur format dan ukuran kertas
    $dompdf->setPaper('A4', 'portrait');

    $dompdf->set_option('isRemoteEnabled', true); // Mengaktifkan pengambilan file eksternal (CSS)
    $dompdf->render();
    // Set header untuk mengunduh file PDF
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="nilai_mahasiswa-'.$_SESSION['name'].'.pdf"');

    // Output file PDF
    echo $dompdf->output();
    exit();
}

?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">

                <?php if($_SESSION['role'] != 'Mahasiswa') : ?>
                    <?php require 'partials/dashboard_sidebar.php'; ?>
                <?php endif ?>

                <?php if($_SESSION['role'] == 'Admin'): ?>
                    <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                        <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white">Hallo, <?= $name ?>!</h1>
                        <canvas id="canvasDatas" width="400" height="100" aria-label="Datas Chart" role="img"></canvas>
                    </div>
                <?php endif ?>

                <?php if($_SESSION['role'] == 'Dosen'): ?>
                    <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                        <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white">Hallo, <?= $name ?>!</h1>
                        <canvas id="canvasMahasiswas" width="400" height="100" aria-label="Mahasiswas Chart" role="img"></canvas>
                    </div>
                <?php endif ?>
                
                <?php if($_SESSION['role'] == 'Mahasiswa'): ?>
                    <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                        <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white">Hallo, <?= $name ?>!</h1>
                        
                        <?php
                        
                            // PHP nya dipisah biar ga numpuk hehe                     
                            require 'views/nilai-mahasiswa.php';                      
                                        
                        ?>                        
                    </div>
                <?php endif ?>
            </div>
        </main>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js"></script>
    <script>
        
        <?php if($_SESSION['role'] == 'Admin'): ?>
            const canvasDatas = $('#canvasDatas')
            var chartDatas = new Chart(canvasDatas, {
                type: 'bar',
                data: {
                    labels: ["Admin", "Dosen", "Mahasiswa", "Jumlah Mata Kuliah"],
                    datasets: [
                        {
                            label: 'Jumlah Users',
                            data: [
                                <?= count($admin) ?>,
                                <?= count($dosen) ?>,
                                <?= count($mahasiswa) ?>,
                            ],
                            borderWidth: 1
                        },
                        {
                            label: 'Jumlah Mata Kuliah',
                            data: [
                                0,0,0,
                                <?= count($matkuls) ?>
                            ],
                            borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    scale: {
                        y: {
                            min: 0,
                            suggestedMax: 10
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Chart.js Bar Chart'
                        }
                    }
                },
            })
        <?php endif ?>
        
        <?php if($_SESSION['role'] == 'Dosen'): ?>
            const canvasMahasiswas = $('#canvasMahasiswas')
            var chartDatas = new Chart(canvasMahasiswas, {
                type: 'bar',
                data: {
                    labels: ["Mahasiswa"],
                    datasets: [
                        {
                            label: 'Jumlah Mahasiswa',
                            data: [
                                <?= count($mahasiswa) ?>,
                            ],
                            borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    scale: {
                        y: {
                            min: 0,
                            suggestedMax: 10
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Chart.js Bar Chart'
                        }
                    }
                },
            })
        <?php endif ?>
        
        
    </script>

</body>
</html>