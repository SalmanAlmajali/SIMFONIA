<?php

    echo '<!-- Create the table -->
        <table class="mt-4">
            <tr>
                <th class="py-2 px-4 border-b text-left">Nama Mahasiswa</th>
                <td class="py-2 px-4 border-b text-left">: '.$name.'</td>
            </tr>
            <tr>
                <th class="py-2 px-4 border-b text-left">NIM</th>
                <td class="py-2 px-4 border-b text-left">: '.$username.'</td>
            </tr>
            <tr>
                <th class="py-2 px-4 border-b text-left">Tahun Akademik</th>
                <td class="py-2 px-4 border-b text-left">: '.$_SESSION['tahunAkademik'].'</td>
            </tr>
        </table>';






    echo '<table id="userTable" class="table-auto border-collapse border-2 w-full rounded-lg mt-4">';
    echo '<thead>
            <tr>
                <th class="border border-gray-300 px-4 py-2">Kode MK</th>
                <th class="border border-gray-300 px-4 py-2">Nama MK</th>
                <th class="border border-gray-300 px-4 py-2">Jumlah SKS</th>
                <th class="border border-gray-300 px-4 py-2">Nilai Absensi</th>
                <th class="border border-gray-300 px-4 py-2">Nilai Tugas</th>
                <th class="border border-gray-300 px-4 py-2">Nilai UTS</th>
                <th class="border border-gray-300 px-4 py-2">Nilai UAS</th>
                <th class="border border-gray-300 px-4 py-2">Nilai Akhir</th>
                <th class="border border-gray-300 px-4 py-2">Angka Mutu</th>
                <th class="border border-gray-300 px-4 py-2">Huruf Mutu</th>
                <th class="border border-gray-300 px-4 py-2">Mutu</th>
            </tr>
        </thead>';

    $totalNilaiMutu = 0; // Variabel untuk menyimpan total nilai UAS

    foreach ($data as $item) {
        if ($item['namaMahasiswa'] == $username) {
            $namaMK = $item['namaMK'];
            foreach ($matkuls as $matkul) {
                if ($matkul['namaMK'] == $namaMK) {
                    $nilaiAkhir = ($item['nilaiKehadiran']*0.1)+($item['nilaiTugas']*0.2)+($item['nilaiUTS']*0.3)+($item['nilaiUAS']*0.4);
                    $angkaMutu = ($nilaiAkhir/100)*4;
                    if($nilaiAkhir >= 85) {
                        $angkaMutu = '4';
                    } elseif($nilaiAkhir >= 70) {
                        $angkaMutu = '3';
                    } elseif($nilaiAkhir >= 60) {
                        $angkaMutu = '2';
                    } elseif($nilaiAkhir >= 50) {
                        $angkaMutu = '1';
                    } elseif($nilaiAkhir < 50) {
                        $angkaMutu = '0';
                    }
                    
                    $hurufMutu ='';
                    
                    if ($angkaMutu >= 3.5) {
                        $hurufMutu = 'A';
                    } elseif ($angkaMutu >= 3.0) {
                        $hurufMutu = 'B';
                    } elseif ($angkaMutu >= 2.75) {
                        $hurufMutu = 'C';
                    } elseif ($angkaMutu >= 2.0) {
                        $hurufMutu = 'D';
                    } elseif ($angkaMutu >= 0) {
                        $hurufMutu = 'E';
                    }
                    
                    $sks += $matkul['sks']; // Menambahkan nilai UAS ke total
                    $mutu = $matkul['sks'] * $angkaMutu;
                    $totalMutu += $mutu;
                    echo '<tr>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $matkul['kodeMK'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $item['namaMK'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $matkul['sks'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $item['nilaiKehadiran'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $item['nilaiTugas'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $item['nilaiUTS'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $item['nilaiUAS'] . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $nilaiAkhir . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $angkaMutu . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $hurufMutu . '</td>';
                    echo '<td class="border border-gray-300 px-4 py-2">' . $mutu . '</td>';
                    echo '</tr>';
                                                    
                }
            }
        }
    }

    $ips = 0; // Variabel untuk menyimpan IPK
    if ($totalMutu > 0) {
        $ips = $totalMutu / $sks; // Menghitung IPK dengan rata-rata nilai UAS
        
    }

    echo '<tr>';
    echo '<td class="border border-gray-300 px-4 py-2 text-bold" colspan="10" style="font-weight: bold;">Indeks Prestasi Semester (IPS)</td>';
    echo '<td class="border border-gray-300 px-4 py-2">' . number_format($ips, 2) . '</td>';
    echo '</tr>';

    echo '</table>';

    // Kode sebelumnya...

?>

<!-- Kode HTML sebelumnya -->

<!-- Tautan untuk memicu pembuatan dan unduhan PDF --><br>
<a class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" href="?generate_pdf=1">Download PDF</a>




                        
           
                        
                        
 