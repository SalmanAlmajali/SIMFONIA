<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">
            
                <?php require 'partials/dashboard_sidebar.php'; ?>

                <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                    <div class="flex flex-row gap-x-2">
                        <a href="/register" class="w-[10rem] text-center p-2 bg-[#0059DB] rounded-lg font-medium text-sm text-white hover:bg-[#0059DB] cursor-pointer">Tambah Data</a>
                        <input type="text" id="searchInput" class="border border-gray-300 rounded-md px-4 py-2 w-full" placeholder="Pencarian ...">
                    </div>
                    <table id="userTable" class="table-auto border-collapse border-2 w-full rounded-lg mt-4">
                        <thead>
                             <tr>
                                <th class="border border-gray-300 px-4 py-2">No</th>
                                <th class="border border-gray-300 px-4 py-2">Username</th>
                                <th class="border border-gray-300 px-4 py-2">Name</th>
                                <th class="border border-gray-300 px-4 py-2">Email</th>
                                <th class="border border-gray-300 px-4 py-2">Role</th>
                                <th class="border border-gray-300 px-4 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="userTableBody">

                        </tbody>
                    </table>
                    <ul id="pagination" class="flex justify-center mt-4"></ul>
                </div>
            </div>
        </main>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        let users = [];
        let currentPage = 1;
        const usersPerPage = 5;

        // Ambil data pengguna dari file JSON
        function getDataFromJson() {
            return fetch('data/users.json')
                .then(response => response.json())
                .then(data => {
                    var filteredData = data.filter((item) => item.role == 'Mahasiswa')
                    // console.log(filteredData);
                    return filteredData;
                });
        }

        // Fungsi untuk mengisi tabel dengan data pengguna
        function populateTable(usersData) {
            const tableBody = document.getElementById('userTableBody');
            tableBody.innerHTML = '';

            usersData.forEach((user, index) => {
                const row = `
                    <tr>
                        <td class="border border-gray-300 px-4 py-2">${index + 1}</td>
                        <td class="border border-gray-300 px-4 py-2">${user.username}</td>
                        <td class="border border-gray-300 px-4 py-2">${user.name}</td>
                        <td class="border border-gray-300 px-4 py-2">${user.email}</td>
                        <td class="border border-gray-300 px-4 py-2">${user.role}</td>
                        <td class="border border-gray-300 px-4 py-2">
                            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded editUser"
                                data-id="${index}">Edit</button>
                            <button class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded" id="delete-user"
                                data-id="${user.username}">Delete</button>
                        </td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        }

        // Fungsi untuk mengatur pagination
        function setupPagination() {
            const paginationContainer = document.getElementById('pagination');
            const totalPages = Math.ceil(users.length / usersPerPage);

            if (totalPages > 1) {
                let paginationHTML = '';

                for (let i = 1; i <= totalPages; i++) {
                    paginationHTML += `
                        <li class="mx-1">
                            <button class="border border-gray-300 px-4 py-2 rounded hover:bg-gray-200 page-link"
                                data-page="${i}">${i}</button>
                        </li>
                    `;
                }

                paginationContainer.innerHTML = paginationHTML;

                // Tambahkan event listener untuk setiap tombol pagination
                const pageLinks = document.querySelectorAll('.page-link');
                pageLinks.forEach(link => {
                    link.addEventListener('click', () => {
                        currentPage = parseInt(link.dataset.page);
                        showUsers();
                    });
                });
            } else {
                paginationContainer.innerHTML = '';
            }
        }

        // Fungsi untuk mencari pengguna berdasarkan kriteria pencarian
        function searchUsers(keyword) {
            const filteredUsers = users.filter(user => {
                return (
                    user.username.toLowerCase().includes(keyword.toLowerCase()) ||
                    user.name.toLowerCase().includes(keyword.toLowerCase()) ||
                    user.email.toLowerCase().includes(keyword.toLowerCase()) ||
                    user.role.toLowerCase().includes(keyword.toLowerCase())
                );
            });
            currentPage = 1;
            showUsers(filteredUsers);
        }

        // Fungsi untuk menghapus pengguna berdasarkan indeks
        $('body').on('click', '#delete-user', function(e) {
            e.preventDefault()

            var username = $(this).attr('data-id')

            Swal.fire({
                icon: 'question',
                text: 'Apakah anda yakin akan menghapus data ini?',
                confirmButtonText: 'Yes',
                showCancelButton: true
            }).then((res) => {
                if(res.isConfirmed) {
                    $.ajax({
                        url: "process/delete_users_process.php",
                        type: "GET",
                        data: {
                            'username': username
                        },
                        success: function(res) {
                            var resParse = JSON.parse(res)

                            if(resParse.success) {
                                Swal.fire({
                                    title: 'Success!',
                                    text: "Data deleted successfully!",
                                    icon: 'success',
                                    confirmButtonText: 'Cool'
                                }).then((res) => {
                                    if(res.isConfirmed) {
                                        location.reload()
                                    }
                                })
                            }
                        },
                        error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        })

        // Fungsi untuk mengedit pengguna berdasarkan indeks
        function editUser(index, newData) {
            // users[index] = newData;

            $.ajax({
                url: "process/update_users_process.php",
                type: "POST",
                data: {
                    username: newData.username,
                    name: newData.name,
                    email: newData.email,
                    role: newData.role,
                    password: newData.password
                },
                success: function(res) {
                    // console.log(res);
                    var resParse = JSON.parse(res)

                    if(resParse.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: "Data updated successfully!",
                            icon: 'success',
                            confirmButtonText: 'Cool'
                        }).then((res) => {
                            if(res.isConfirmed) {
                                location.reload()
                            }
                        })
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            })

            showUsers();
        }

        // Fungsi untuk menampilkan SweetAlert konfirmasi dan menghapus pengguna
        // function confirmAndDeleteUser() {
        //     swal({
        //         title: 'Yakin Mau Menghapus User ?',
        //         text: 'Setelah dihapus, data tidak dapat dikembalikan lagi!',
        //         icon: 'warning',
        //         buttons: ['Cancel', 'Delete'],
        //         dangerMode: true,
        //     }).then((willDelete) => {
        //         if (willDelete) {
        //             deleteUser();
        //         }
        //     });
        // }

        // Fungsi untuk menampilkan SweetAlert konfirmasi dan mengedit pengguna
        function confirmAndEditUser(index) {
            const user = users[index];

            swal({
                title: 'Edit User',
                content: {
                    element: 'div',
                    attributes: {
                        innerHTML: `
                            <div>
                                <label for="editUsername">Username</label>
                                <input type="text" id="editUsername" class="border border-gray-300 rounded-md px-4 py-2 w-full mb-2"
                                    value="${user.username}" disabled>
                            </div>
                            <div>
                                <label for="editName">Name</label>
                                <input type="text" id="editName" class="border border-gray-300 rounded-md px-4 py-2 w-full mb-2"
                                    value="${user.name}">
                            </div>
                            <div>
                                <label for="editEmail">Email</label>
                                <input type="email" id="editEmail" class="border border-gray-300 rounded-md px-4 py-2 w-full mb-2"
                                    value="${user.email}">
                            </div>
                            <div>
                                <label for="editRole">Role</label>
                                <select id="editRole" class="border border-gray-300 rounded-md px-4 py-2 w-full mb-2" disabled>
                                    <option value="Mahasiswa" ${user.role === 'Mahasiswa' ? 'selected' : ''}>Mahasiswa</option>
                                    <option value="Dosen" ${user.role === 'Dosen' ? 'selected' : ''}>Dosen</option>
                                    <option value="Admin" ${user.role === 'Admin' ? 'selected' : ''}>Admin</option>
                                </select>
                            </div>
                            <div>
                                <label for="editPassword">Password</label>
                                <input type="text" id="editPassword" class="border border-gray-300 rounded-md px-4 py-2 w-full mb-2"
                                    value="${user.password}">
                            </div>
                        `,
                    },
                },
                buttons: {
                    cancel: 'Cancel',
                    confirm: 'Save',
                },
                closeOnClickOutside: false,
                closeOnEsc: false,
            }).then((confirmed) => {
                if (confirmed) {
                    const editedUser = {
                        username: document.getElementById('editUsername').value,
                        name: document.getElementById('editName').value,
                        email: document.getElementById('editEmail').value,
                        role: document.getElementById('editRole').value,
                        password: document.getElementById('editPassword').value
                    };
                    editUser(index, editedUser);
                }
            });
        }

        // Fungsi untuk menampilkan data pengguna dengan memperhatikan pagination
        function showUsers(filteredUsers = []) {
            const startIndex = (currentPage - 1) * usersPerPage;
            const endIndex = startIndex + usersPerPage;
            const displayedUsers = filteredUsers.length > 0 ? filteredUsers : users.slice(startIndex, endIndex);

            populateTable(displayedUsers);
            setupPagination();
        }

        // Event listener untuk input pencarian
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('input', () => {
            const keyword = searchInput.value.trim();
            searchUsers(keyword);
        });

        // Event listener untuk tombol edit dan delete
        const userTableBody = document.getElementById('userTableBody');
        userTableBody.addEventListener('click', (event) => {
            if (event.target.classList.contains('deleteUser')) {
                const index = parseInt(event.target.dataset.id);
                confirmAndDeleteUser(index);
            } else if (event.target.classList.contains('editUser')) {
                const index = parseInt(event.target.dataset.id);
                confirmAndEditUser(index);
            }
        });

        // Jalankan inisialisasi halaman
        function initializePage() {
            getDataFromJson().then(data => {
                users = data;
                showUsers();
            });
        }

        initializePage();
    </script>
</body>
</html>