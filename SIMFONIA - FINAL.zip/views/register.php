<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">

		<?php require 'partials/dashboard_nav.php'; ?>
			
		<?php require 'partials/dashboard_header.php'; ?>

		<main>
			<div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">

				<?php require 'partials/dashboard_sidebar.php'; ?>

				<div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
					<form id="registerForm" action="#" method="POST" class="flex flex-col p-4 gap-y-4">
						<div class="flex flex-col gap-y-2">
							<label for="username" class="block">
								<span class="block text-sm font-medium text-slate-700">NIM / Username</span>
								<input type="text" id="username" name="username" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
							</label>
						</div>

						<div class="flex flex-col gap-y-2">
							<label for="name" class="block">
								<span class="block text-sm font-medium text-slate-700">Name</span>
								<input type="text" id="name" name="name" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
							</label>
						</div>
						
						<div class="flex flex-col gap-y-2">
							<label for="email" class="block">
								<span class="block text-sm font-medium text-slate-700">Email</span>
								<input type="email" id="email" name="email" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
							</label>
						</div>
						
						<div class="flex flex-col gap-y-2">
							<label for="role" class="block">
								<span class="block text-sm font-medium text-slate-700">Role</span>
								<select name="role" id="role" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
									<!-- <option value="Admin">Admin</option> -->
									<option value="Dosen">Dosen</option>
									<option value="Mahasiswa">Mahasiswa</option>
								</select>
							</label>
						</div>

						<div id="tahunAkademikField" style="display: none;">
							<label for="academicYear" class="block">
								<span class="block text-sm font-medium text-slate-700">Tahun Akademik</spanl>
								<select id="tahunAkademik" name="tahunAkademik" class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
									<option value="2022-2023">2022-2023</option>
									<option value="2023-2024">2023-2024</option>
									<option value="2024-2025">2024-2025</option>
								</select>
							</label>
						</div>

						<div class="flex flex-col gap-y-2">
							<label for="password" class="block">
								<span class="block text-sm font-medium text-slate-700">Password</span>
								<input type="password" id="password" name="password" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
							</label>
						</div>
						
						<div class="flex flex-col gap-y-2">
							<label for="retypePassword" class="block">
								<span class="block text-sm font-medium text-slate-700">Password Confirmation</span>
								<input type="password" id="retypePassword" name="retypePassword" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
							</label>
						</div>
						
						<input type="submit" value="Register" class="p-2 bg-[#0059DB] rounded-lg font-medium uppercase text-sm text-white hover:bg-[#0059DB] cursor-pointer">
					</form>
				</div>
			</div>		
		</main>
	</div>

	<?php require 'partials/dashboard_footer.php'; ?>
    <script>
        var registrations = []; // Array untuk menyimpan data pendaftaran

		// Fungsi untuk membaca file JSON
		function readRegistrations() {
			$.getJSON('./data/users.json', function(data) {
				registrations = data; // Simpan data dari file JSON ke dalam array registrations
			});
		}

		$(document).ready(function() {
			readRegistrations(); // Panggil fungsi untuk membaca file JSON saat halaman dimuat

			$('#registerForm').submit(function(event) {
				event.preventDefault(); 

				// ambil data
				var formData = {
					username: $('#username').val(),
					name: $('#name').val(),
					role: $('#role').val(),
					email: $('#email').val(),
					password: $('#password').val(),
					retypePassword: $('#retypePassword').val(),
					tahunAkademik: $('#tahunAkademik').val()
				};

				// Validasi kata sandi
				if (formData.password !== formData.retypePassword) {
					Swal.fire({
						icon: 'error',
						status: 'error',
						title: 'Validation Error',
						text: 'Passwords do not match'
					})
					return;
				}

				// Cek jika username atau email sudah terdaftar
				var usernameExists = false;
				var emailExists = false;

				for (var i = 0; i < registrations.length; i++) {
					if (registrations[i].username === formData.username) {
						usernameExists = true;
						break;
					}

					if (registrations[i].email === formData.email) {
						emailExists = true;
						break;
					}
				}

				if (usernameExists || emailExists) {
						Swal.fire({
                            title: 'Data Exists!',
                            text: "Username or email already exists",
                            icon: 'error',
                            confirmButtonText: 'Cool'
                        })
					return;
				}

				// tambahkan data pendaftaran ke Array
				registrations.push(formData);

				// lakukan ajax untuk save data
				$.ajax({
					url: 'process/daftar_proses.php', 
					type: 'POST',
					dataType: 'json',
					data: formData,
					success: function(response) {
						// var resParse = JSON.parse(response)
						if(response.success) {
							Swal.fire({
                                title: 'Success!',
                                text: "Register successfully!",
                                icon: 'success',
                                confirmButtonText: 'Cool'
                            }).then((res) => {
                                if(res.isConfirmed) {
                                    location.reload()
                                }
                            })
						}
						$('#registerForm')[0].reset(); // hapus inputan setelah isi data
					},
					error: function(xhr, status, error) {
						Swal.fire({
                            title: 'Success!',
                            text: "Failed to save data! " + error,
                            icon: 'success',
                            confirmButtonText: 'Cool'
                        })
					}
				});
			});
			
			$('#role').change(function() {
				var role = $(this).val();

				if (role === 'Mahasiswa') {
					$('#tahunAkademikField').show();
				} else {
					$('#tahunAkademikField').hide();
				}
			});
		});
    </script>
</body>
</html>