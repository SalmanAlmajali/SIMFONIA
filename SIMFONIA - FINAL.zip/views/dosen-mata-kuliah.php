<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">
            
                <?php require 'partials/dashboard_sidebar.php'; ?>

                <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">

                    <div class="flex flex-col gap-y-2">
                        <?php foreach($matkul as $item): ?>
                            <a href="/input-nilai?<?= $item['MataKuliah']['namaMK'] ?>" class="inline-block w-full p-4 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-sm font-medium">
                                <?= $item['MataKuliah']['namaMK'] ?>
                            </a>
                        <?php endforeach ?>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <div id="modal" class="hidden absolute top-0 w-full h-screen bg-black/50 backdrop-blur-md p-4 z-10 flex flex-col justify-center items-center">
        <div class="w-full bg-white p-4 rounded-lg md:w-1/2">
            <form id="formInputNilai" action="#" method="POST" class="flex flex-col gap-y-4">
                
                <div class="flex flex-row gap-x-4">
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMahasiswa" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mahasiswa</span>
                                <input type="text" id="namaMahasiswa" name="namaMahasiswa" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1" readonly>
                            </label>
                        </div>
        
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMK" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mata Kuliah</span>
                                <input type="text" id="namaMK" name="namaMK" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="sks" class="block">
                                <span class="block text-sm font-medium text-slate-700">SKS</span>
                                <input type="number" id="sks" name="sks" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="dosenPengajar" class="block">
                                <span class="block text-sm font-medium text-slate-700">Dosen Pengajar</span>
                                <input type="text" id="dosenPengajar" name="dosenPengajar" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiKehadiran" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Kehadiran</span>
                                <input type="number" id="nilaiKehadiran" name="nilaiKehadiran" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiTugas" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Tugas</span>
                                <input type="number" id="nilaiTugas" name="nilaiTugas" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUTS" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UTS</span>
                                <input type="number" id="nilaiUTS" name="nilaiUTS" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUAS" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UAS</span>
                                <input type="number" id="nilaiUAS" name="nilaiUAS" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                </div>
                

                <div class="flex justify-end gap-x-2">
                    <button id="cancel" type="button" class="bg-slate-500 p-2 rounded-lg text-sm font-medium text-white w-[8rem]">Cancel</button>
                    <button id="save" class="bg-[#0059DB] p-2 rounded-lg text-sm font-medium text-white w-[8rem] hover:bg-[#0059DB]">Save</button>
                </div>

            </form>
        </div>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>
</body>
</html>