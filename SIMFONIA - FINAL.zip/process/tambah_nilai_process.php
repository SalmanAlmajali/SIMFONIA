<?php

    $namaMahasiswa = $_POST['namaMahasiswa'];
    $namaMK = $_POST['namaMK'];
    $dosenPengajar = $_POST['dosenPengajar'];
    $nilaiKehadiran = $_POST['nilaiKehadiran'];
    $nilaiTugas = $_POST['nilaiTugas'];
    $nilaiUTS = $_POST['nilaiUTS'];
    $nilaiUAS = $_POST['nilaiUAS'];

    $data = array(
        'namaMahasiswa' => $namaMahasiswa,
        'namaMK' => $namaMK,
        'dosenPengajar' => $dosenPengajar,
        'nilaiKehadiran' => $nilaiKehadiran,
        'nilaiTugas' => $nilaiTugas,
        'nilaiUTS' => $nilaiUTS,
        'nilaiUAS' => $nilaiUAS,
    );

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/nilais.json';
    $nilais = array();

    if(file_exists($filename)) {
        $nilais = json_decode(file_get_contents($filename), true);
    }

    // Menambahkan data yang diinput kedalam fileJSON
    $nilais[] = $data;

    // Menyinpan data baru ke dalam file JSON
    file_put_contents($filename, json_encode($nilais));

    // Return pesan sukses
    $response = array('success' => true);

    header("Content-Type: application/json");
    echo json_encode($response);