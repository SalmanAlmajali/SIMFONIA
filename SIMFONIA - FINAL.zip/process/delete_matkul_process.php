<?php
    $kodeMK = $_GET['kodeMK'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/matkuls.json';
    $matkuls = array();

    if(file_exists($filename)) {
        $matkuls = json_decode(file_get_contents($filename), true);
        for($i = 0; $i < count($matkuls); $i++) {
            if($matkuls[$i]['kodeMK'] === $kodeMK) {
                // unset($matkuls[$i]);
                array_splice($matkuls, $i, 1);
                // Menyinpan data baru ke dalam file JSON
                file_put_contents($filename, json_encode($matkuls));

                // Return pesan sukses
                $response = array('success' => true);

                echo json_encode($response);
            }
        }
    }
