<?php

    $namaMahasiswa = $_POST['namaMahasiswa'];
    $namaMK = $_POST['namaMK'];
    $dosenPengajar = $_POST['dosenPengajar'];
    $nilaiKehadiran = $_POST['nilaiKehadiran'];
    $nilaiTugas = $_POST['nilaiTugas'];
    $nilaiUTS = $_POST['nilaiUTS'];
    $nilaiUAS = $_POST['nilaiUAS'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/nilais.json';
    $nilais = array();

    if(file_exists($filename)) {
        $nilais = json_decode(file_get_contents($filename), true);
        for($i = 0; $i < count($nilais); $i++) {
            if($nilais[$i]['namaMahasiswa'] === $namaMahasiswa && $nilais[$i]['namaMK'] == $namaMK) {
                $nilais[$i]['nilaiKehadiran'] = $nilaiKehadiran;
                $nilais[$i]['nilaiTugas'] = $nilaiTugas;
                $nilais[$i]['nilaiUTS'] = $nilaiUTS;
                $nilais[$i]['nilaiUAS'] = $nilaiUAS;

                // Menyinpan data baru ke dalam file JSON
                file_put_contents($filename, json_encode($nilais));

                // Return pesan sukses
                $response = array('success' => true);

                echo json_encode($response);
            }
        }
    }