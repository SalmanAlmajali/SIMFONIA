<?php
    // Get form data
    $username = $_POST['username'];
    $name = $_POST['name'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = $_POST['password'];
    if($role == 'Mahasiswa') {
        $tahunAkademik = $_POST['tahunAkademik'];
    } else {
        $tahunAkademik = '';
    }

    // Create an array with the data
    $data = array(
        'username' => $username,
        'name' => $name,
        'role' => $role,
        'email' => $email,
        'password' => $password,
        'tahunAkademik' => $tahunAkademik
    );

    // Load existing data from JSON file
    $filename = '../data/users.json';
    $registrations = array();
    if (file_exists($filename)) {
        $registrations = json_decode(file_get_contents($filename), true);
    }

    // Add new registration to the array
    $registrations[] = $data;

    // Save updated data to JSON file
    file_put_contents($filename, json_encode($registrations));

    // Return success message
    $response = array('success' => true);
    echo json_encode($response);
?>