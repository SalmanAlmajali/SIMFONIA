<?php 

    $username = $_GET['username'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/users.json';
    $users = array();

    if(file_exists($filename)) {
        $users = json_decode(file_get_contents($filename), true);
        
        for($i = 0; $i < count($users); $i++) {
            if($users[$i]['username'] === $username && $users[$i]['role'] === 'Dosen') {
                unset($users[$i]);
                // // Menyimpan data baru ke dalam file JSON

                file_put_contents($filename, json_encode($users));
                
                // // Return pesan sukses
                $response = array('success' => true);

                echo json_encode($response);
            }
        }
    }