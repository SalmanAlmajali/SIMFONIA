function getUserActive() {
    if(!active) {
        location.replace('/')
    }
}