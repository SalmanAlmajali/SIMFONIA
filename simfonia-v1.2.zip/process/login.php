<?php
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/users.json';
    $users = array();

    $response = array("success" => false);

    if(file_exists($filename)) {
        $users = json_decode(file_get_contents($filename), true);

        // Mengecek kesamaan data yang dinput dan data yang tersimpan di dalam file
        foreach ($users as $user) {
            if ($user["username"] === $username && $user["password"] === $password) {
                session_start();
            
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['tahunAkademik'] = $user['tahunAkademik'];
                $_SESSION['isLogin'] = true;

                // Return pesan sukses
                $response["success"] = true;
                break;
            }
        }

    }
    
    header("Content-Type: application/json");
    echo json_encode($response);
