<?php
    $namaMahasiswa = $_GET['namaMahasiswa'];
    $namaMK = $_GET['namaMK'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/nilais.json';
    $nilais = array();
    $nilai = array();

    $response = false;
 
    if(file_exists($filename)) {
        $nilais = json_decode(file_get_contents($filename), true);
        for($i = 0; $i < count($nilais); $i++) {
            if($nilais[$i]['namaMahasiswa'] === $namaMahasiswa && $nilais[$i]['namaMK'] == $namaMK) {
                $response = true;
                $nilai = $nilais[$i];

                break;
            }
        }
    }

    echo json_encode(array(
        'data' => $nilai,
        'success' => $response
    ));