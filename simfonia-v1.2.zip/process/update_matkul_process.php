<?php
    $id = $_POST['id'];
    // $kodeMK = $_POST['kodeMK'];
    $namaMK = $_POST['namaMK'];

    // Membaca data yang tersedia dari file JSON
    $filename = '../data/matkuls.json';
    $matkuls = array();
    $matakuliah = '';

    $fileNilais = '../data/nilais.json';
    $nilais = array();

    if(file_exists($filename) && file_exists($fileNilais)) {
        $matkuls = json_decode(file_get_contents($filename), true);

        for($i = 0; $i < count($matkuls); $i++) {
            if($matkuls[$i]['kodeMK'] === $id) {
                // $matkuls[$i]['kodeMK'] = $kodeMK;
                $matakuliah = $matkuls[$i]['namaMK'];
                $matkuls[$i]['namaMK'] = $namaMK;

                // Menyinpan data baru ke dalam file JSON
                file_put_contents($filename, json_encode($matkuls));
            }
        }

        $nilais = json_decode(file_get_contents($fileNilais), true);

        // if(!empty($nilais)) {
            for ($i=0; $i < count($nilais); $i++) { 
                if($nilais[$i]['namaMK'] === $matakuliah) {
                    $nilais[$i]['namaMK'] = $namaMK;

                    // Menyinpan data baru ke dalam file JSON
                    file_put_contents($fileNilais, json_encode($nilais));
                }
            }
        // }
    }

    // Return pesan sukses
    $response = array('success' => true);

    echo json_encode($response);