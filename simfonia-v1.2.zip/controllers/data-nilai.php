<?php

    checkSession();

    $title = "Daftar Dosen";

    $header = 'Data Nilai';

    require './views/data-nilai.php';