<?php
    checkSession();

    $title = "Dashboard";

    $name = $_SESSION['name'];

    // Membaca data yang tersedia dari file JSON
    $filename = './data/users.json';
    $fileMatkul = './data/matkuls.json';

    $users = array();
    $admin = array();
    $dosen = array();
    $mahasiswa = array();

    $matkuls = array();

    if(file_exists($filename) && file_exists($fileMatkul)) {
        $users = json_decode(file_get_contents($filename), true);

        for ($i=0; $i < count($users); $i++) { 
            if($users[$i]['role'] == 'Admin') {
                $admin[$i] = $users[$i];
            } else if($users[$i]['role'] == 'Dosen') {
                $dosen[$i] = $users[$i];
            } else {
                $mahasiswa[$i] = $users[$i];
            }
        }

        $matkuls = json_decode(file_get_contents($fileMatkul), true);
    }

    require './views/dashboard.php';