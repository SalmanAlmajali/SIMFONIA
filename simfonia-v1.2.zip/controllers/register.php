<?php

    checkSession();

    $title = "Register";

    require './views/register.php';