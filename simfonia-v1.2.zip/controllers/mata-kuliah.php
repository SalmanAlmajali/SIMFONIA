<?php
    checkSession();

    $title = "Data Mata Kuliah";

    // Membaca data yang tersedia dari file JSON
    $filename = './data/matkuls.json';
    $fileUsers = './data/users.json';
    $matkuls = array();
    $users = array();
    $filteredUsers = array();

    if(file_exists($filename) && file_exists($fileUsers)) {
        $matkuls = json_decode(file_get_contents($filename), true);
        $users = json_decode(file_get_contents($fileUsers), true);

        for ($i=0; $i < count($users); $i++) { 
            if($users[$i]['role'] == 'Dosen') {
                $filteredUsers[$i] = $users[$i];
            }
        }
    }

    require './views/mata-kuliah.php';