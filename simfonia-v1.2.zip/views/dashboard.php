<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">
            
                <?php require 'partials/dashboard_sidebar.php'; ?>

                <?php if($_SESSION['role'] == 'Admin'): ?>
                    <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                        <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white">Hallo, <?= $name ?>!</h1>
                        <canvas id="canvasDatas" width="400" height="100" aria-label="Datas Chart" role="img"></canvas>
                    </div>
                <?php endif ?>

                <?php if($_SESSION['role'] == 'Dosen'): ?>
                    <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">
                        <h1 id="greeting" class="text-3xl font-bold tracking-tight text-gray-900 bg-[#0059DB] p-2 rounded-lg text-white">Hallo, <?= $name ?>!</h1>
                        <canvas id="canvasMahasiswas" width="400" height="100" aria-label="Mahasiswas Chart" role="img"></canvas>
                    </div>
                <?php endif ?>
            </div>
        </main>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js"></script>
    <script>
        
        <?php if($_SESSION['role'] == 'Admin'): ?>
            const canvasDatas = $('#canvasDatas')
            var chartDatas = new Chart(canvasDatas, {
                type: 'bar',
                data: {
                    labels: ["Admin", "Dosen", "Mahasiswa", "Jumlah Mata Kuliah"],
                    datasets: [
                        {
                            label: 'Jumlah Users',
                            data: [
                                <?= count($admin) ?>,
                                <?= count($dosen) ?>,
                                <?= count($mahasiswa) ?>,
                            ],
                            borderWidth: 1
                        },
                        {
                            label: 'Jumlah Mata Kuliah',
                            data: [
                                0,0,0,
                                <?= count($matkuls) ?>
                            ],
                            borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    scale: {
                        y: {
                            min: 0,
                            suggestedMax: 10
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Chart.js Bar Chart'
                        }
                    }
                },
            })
        <?php endif ?>
        
        <?php if($_SESSION['role'] == 'Dosen'): ?>
            const canvasMahasiswas = $('#canvasMahasiswas')
            var chartDatas = new Chart(canvasMahasiswas, {
                type: 'bar',
                data: {
                    labels: ["Mahasiswa"],
                    datasets: [
                        {
                            label: 'Jumlah Mahasiswa',
                            data: [
                                <?= count($mahasiswa) ?>,
                            ],
                            borderWidth: 1
                        },
                    ]
                },
                options: {
                    responsive: true,
                    scale: {
                        y: {
                            min: 0,
                            suggestedMax: 10
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Chart.js Bar Chart'
                        }
                    }
                },
            })
        <?php endif ?>
    </script>
</body>
</html>