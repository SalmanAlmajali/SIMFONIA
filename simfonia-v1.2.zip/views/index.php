<?php require 'partials/login_head.php'; ?>

<body>
    <div class="container mx-auto px-4 py-4 h-screen flex justify-center items-center">
        <div class="flex flex-col gap-y-4 w-full md:w-1/2 lg:w-1/3">
            <img src="./asset/img/logo-primary.jpg" alt="Logo SIMFONIA" class="rounded-lg">
            <div class="bg-white rounded-lg p-4 border-2 border-gray-300 shadow-lg">
                <form id="logInForm" action="#" method="POST" class="flex flex-col p-4 gap-y-4">
                    <div class="flex flex-col gap-y-2">
                        <label for="username" class="block">
                            <span class="block text-sm font-medium text-slate-700">NIM</span>
                            <input type="username" id="username" name="username" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                        </label>
                    </div>
                    
                    <div class="flex flex-col gap-y-2">
                        <label for="password" class="block">
                            <span class="block text-sm font-medium text-slate-700">Password</span>
                            <input type="password" id="password" name="password" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                        </label>
                    </div>
                    
                    <button id="saveEdit" class="bg-[#0059DB] p-2 rounded-lg text-sm font-medium text-white w-[8rem] hover:bg-[#0059DB] w-full">Log In</button>
                </form>
            </div>
        </div>
    </div>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {

            var maxAttempts = 3;
            var loginAttempts = localStorage.getItem('loginAttempts');
            var lastResetTime = localStorage.getItem("lastResetTime");
            var currentTime = new Date().getTime();
            var elapsedSeconds = (currentTime - lastResetTime) / 1000;
            var countdownTime = 30; // Waktu countdown dalam detik
            var countdownInterval;

            // Fungsi untuk menampilkan popup SweetAlert
            function showPopup() {
                Swal.fire({
                    title: 'Login Gagal',
                    html: 'Kamu sudah gagal login sebanyak 3 kali. Login kembali setelah <b></b> milidetik.',
                    icon: 'warning',
                    showConfirmButton: false,
                    timer: 30000,
                    timerProgressBar: true,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    allowEnterKey: false,
                    didOpen: () => {
                        Swal.showLoading()
                        const b = Swal.getHtmlContainer().querySelector('b')
                        timerInterval = setInterval(() => {
                            b.textContent = Swal.getTimerLeft()
                        }, 100)
                    },
                    willClose: () => {
                        clearInterval(timerInterval)
                    }
                });

            }

            $("#logInForm").submit(function(e) {
                e.preventDefault()

                var messageElement = $('#message');
                var lastLoginTime = localStorage.getItem('lastLoginTime');
                var currentTime = new Date().getTime();

                if (lastLoginTime && currentTime - lastLoginTime < 30000) {
                    showPopup();
                }

                if(loginAttempts >= 3) {

                    const countdownDuration = 30; // Durasi countdown dalam detik

                    // Mengecek apakah countdown sudah ada di localStorage
                    if (!localStorage.getItem("countdownStart")) {
                        // Jika tidak ada, inisialisasi countdown
                        const currentTime = Math.floor(Date.now() / 1000); // Waktu saat ini dalam detik
                        localStorage.setItem("countdownStart", currentTime);
                    }

                    // Mengupdate countdown setiap detik
                    const countdown = setInterval(() => {
                    const countdownStart = parseInt(localStorage.getItem("countdownStart")); // Waktu awal countdown
                    const currentTime = Math.floor(Date.now() / 1000); // Waktu saat ini dalam detik
                    const elapsedSeconds = currentTime - countdownStart; // Selisih waktu

                    // Menghitung waktu countdown yang tersisa
                    const remainingSeconds = countdownDuration - elapsedSeconds;
                    messageElement.html('Login Gagal. Tunggu '+  remainingSeconds + ' detik untuk login kembali.');
                                        
                    if (remainingSeconds <= 0) {
                        // Hapus loginAttempts dari localStorage
                        localStorage.removeItem("loginAttempts");

                        // Hapus countdownStart dari localStorage
                        localStorage.removeItem("countdownStart");
                        
                        // Me-refresh halaman saat ini
                        location.reload();


                        // Hentikan countdown
                        clearInterval(countdown);
                    } else {
                        // Tampilkan waktu countdown yang tersisa
                        console.log("Waktu countdown yang tersisa:", remainingSeconds, "detik");
                    }
                    }, 1000);
                    showPopup();
                } else {
                    // Ambil data
                    var formData = {
                        username : $("#username").val(),
                        password : $("#password").val()
                    }
    
                    // Request login
                    $.ajax({
                        url: "process/login.php",
                        type: "POST",
                        data: formData,
                        success: function(res) {
                            console.log(res);
                            // var resParse = JSON.parse(res)
                            if(res.success) {
                                loginAttempts = 0;
                                localStorage.setItem('loginAttempts', loginAttempts);

                                location.replace('/dashboard')
                            } else {
                                loginAttempts++;
                                localStorage.setItem('loginAttempts', loginAttempts);
                                messageElement.html("Username atau password salah");

                                Swal.fire({
                                    title: "Login Failed!",
                                    icon: 'error',
                                    status: 'error',
                                    text: "Email or Password is not exists!"
                                }).then((res) => {
                                    if(res.isConfirmed) {
                                        console.log(res);
                                    }
                                })
                            }
                        },
                        error: function(error) {
                            console.log(error);
                        }
                    })
                }
            })
        })
    </script>
</body>
</html>