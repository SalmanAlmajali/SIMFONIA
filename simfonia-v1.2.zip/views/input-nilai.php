<?php require 'partials/dashboard_head.php'; ?>

<body class="h-full">
    <div class="min-h-full">
    
        <?php require 'partials/dashboard_nav.php'; ?>
        
        <?php require 'partials/dashboard_header.php'; ?>
        
        <main>
            <div class="mx-auto py-6 flex flex-row gap-x-4 sm:px-6 lg:px-8">
            
                <?php require 'partials/dashboard_sidebar.php'; ?>
                
                <!-- <?php print_r($matkul); ?> -->

                <div class="w-full bg-white px-4 py-6 shadow-lg rounded-lg">

                    <table class="table-auto border-collapse border-2 w-full rounded-lg mt-4">
                        <thead>
                            <tr>
                                <th class="border border-gray-300 px-4 py-2">No</th>
                                <th class="border border-gray-300 px-4 py-2">NIM</th>
                                <th class="border border-gray-300 px-4 py-2">Nama Mahasiswa</th>
                                <th class="border border-gray-300 px-4 py-2">Email</th>
                                <th class="border border-gray-300 px-4 py-2"></th>
                            </tr>
                            <tbody>
                                <?php foreach($filteredUsers as $key => $mahasiswa) : ?>
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <?= $key -1 ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <?= $mahasiswa['username'] ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <?= $mahasiswa['name'] ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <?= $mahasiswa['email'] ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <a href="#" id="triggerInput" data-id="<?= $mahasiswa['username'] ?>" data-name="<?= $mahasiswa['name'] ?>" class="inline-block bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Input Nilai</a>
                                            <a href="#" id="triggerEdit" data-id="<?= $mahasiswa['username'] ?>" class="inline-block bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded">Edit Nilai</a>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </thead>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <div id="modal" class="hidden absolute top-0 w-full h-screen bg-black/50 backdrop-blur-md p-4 z-10 flex flex-col justify-center items-center">
        <div class="w-full bg-white p-4 rounded-lg md:w-1/2">
            <form id="formInputNilai" action="#" method="POST" class="flex flex-col gap-y-4">
                
                <div class="flex flex-row gap-x-4">
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMahasiswa" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mahasiswa</span>
                                <input type="text" id="namaMahasiswa" name="namaMahasiswa" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1" readonly>
                            </label>
                        </div>
        
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMK" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mata Kuliah</span>
                                <input type="text" id="namaMK" name="namaMK" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="dosenPengajar" class="block">
                                <span class="block text-sm font-medium text-slate-700">Dosen Pengajar</span>
                                <input type="text" id="dosenPengajar" name="dosenPengajar" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiKehadiran" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Kehadiran</span>
                                <input type="number" id="nilaiKehadiran" name="nilaiKehadiran" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiTugas" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Tugas</span>
                                <input type="number" id="nilaiTugas" name="nilaiTugas" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUTS" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UTS</span>
                                <input type="number" id="nilaiUTS" name="nilaiUTS" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUAS" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UAS</span>
                                <input type="number" id="nilaiUAS" name="nilaiUAS" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                </div>
                

                <div class="flex justify-end gap-x-2">
                    <button id="cancel" type="button" class="bg-slate-500 p-2 rounded-lg text-sm font-medium text-white w-[8rem]">Cancel</button>
                    <button id="save" class="bg-[#0059DB] p-2 rounded-lg text-sm font-medium text-white w-[8rem] hover:bg-[#0059DB]">Save</button>
                </div>

            </form>
        </div>
    </div>
    
    <div id="modalEdit" class="hidden absolute top-0 w-full h-screen bg-black/50 backdrop-blur-md p-4 z-10 flex flex-col justify-center items-center">
        <div class="w-full bg-white p-4 rounded-lg md:w-1/2">
            <form id="formEdit" action="#" method="POST" class="flex flex-col gap-y-4">
                
                <div class="flex flex-row gap-x-4">
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMahasiswaEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mahasiswa</span>
                                <input type="text" id="namaMahasiswaEdit" name="namaMahasiswaEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1" readonly>
                            </label>
                        </div>
        
                        <div class="flex flex-col gap-y-2">
                            <label for="namaMKEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nama Mata Kuliah</span>
                                <input type="text" id="namaMKEdit" name="namaMKEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="dosenPengajarEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Dosen Pengajar</span>
                                <input type="text" id="dosenPengajarEdit" name="dosenPengajarEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                    <div class="flex-1 flex flex-col gap-y-2">
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiKehadiranEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Kehadiran</span>
                                <input type="number" id="nilaiKehadiranEdit" name="nilaiKehadiranEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiTugasEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai Tugas</span>
                                <input type="number" id="nilaiTugasEdit" name="nilaiTugasEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUTSEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UTS</span>
                                <input type="number" id="nilaiUTSEdit" name="nilaiUTSEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                        
                        <div class="flex flex-col gap-y-2">
                            <label for="nilaiUASEdit" class="block">
                                <span class="block text-sm font-medium text-slate-700">Nilai UAS</span>
                                <input type="number" id="nilaiUASEdit" name="nilaiUASEdit" required class="mt-1 px-3 py-2 bg-white border shadow-sm border-slate-300 placeholder-slate-400 focus:outline-none focus:border-[#0059DB] focus:ring-[#0059DB] block w-full rounded-md sm:text-sm focus:ring-1">
                            </label>
                        </div>
                    </div>
                </div>
                

                <div class="flex justify-end gap-x-2">
                    <button id="cancelEdit" type="button" class="bg-slate-500 p-2 rounded-lg text-sm font-medium text-white w-[8rem]">Cancel</button>
                    <button id="save" class="bg-[#0059DB] p-2 rounded-lg text-sm font-medium text-white w-[8rem] hover:bg-[#0059DB]">Save</button>
                </div>

            </form>
        </div>
    </div>

    <?php require 'partials/dashboard_footer.php'; ?>
    <script>

        var id, name, index, namaMahasiswa

        $('body').on('click', '#triggerInput', function(e) {
            e.preventDefault()

            id = $(this).attr('data-id'),
            name = $(this).attr('data-name'),
            index = $(this).attr('data-index')

            $("#namaMahasiswa").val(name)
            $("#namaMK").val("<?= htmlentities(urldecode($_SERVER['QUERY_STRING'])) ?>")
            $("#dosenPengajar").val("<?= $_SESSION['name'] ?>")

            $('#modal').removeClass('hidden')
            document.body.classList.add('overflow-hidden')

            scrollTo(0, 0)
        })

        $('body').on('click', '#cancel', function(e) {
            e.preventDefault()
            
            $('#formInputNilai')[0].reset() // Mengosongkan inputan pada form
            $('#modal').addClass('hidden')
            document.body.classList.remove('overflow-hidden')
        })

        $('body').on('click', '#cancelEdit', function(e) {
            e.preventDefault()

            $('#modalEdit').addClass('hidden')
            document.body.classList.remove('overflow-hidden')
        })

        var nilais = [] // Array untuk menyimpan data mata kuliah

        // Fungsi untuk membaca file JSON
        function readNilais() {
            $.getJSON('./data/nilais.json', function(data) {
                nilais = data.filter((item) => item.namaMK === "<?= htmlentities(urldecode($_SERVER['QUERY_STRING'])) ?>") // Simpan data dari file JSON ke dalam array matkuls
            })
        }

        $(document).ready(function() {
            readNilais()

            $("#formInputNilai").submit(function(e) {
                e.preventDefault()
    
                var formData = {
                    namaMahasiswa : id,
                    namaMK : $('#namaMK').val(),
                    dosenPengajar : "<?= $_SESSION['username'] ?>",
                    nilaiKehadiran : $('#nilaiKehadiran').val(),
                    nilaiTugas : $('#nilaiTugas').val(),
                    nilaiUTS : $('#nilaiUTS').val(),
                    nilaiUAS : $('#nilaiUAS').val(),
                }

                // Validasi apabila kodeMK sudah terdaftar
                var mahasiswaExists = false,
                    namaMKExists = false

                
                for(let i = 0; i < nilais.length; i++) {
                    if(nilais[i].namaMahasiswa === formData.namaMahasiswa) {
                        mahasiswaExists = true
                    }

                    if(nilais[i].namaMK === formData.namaMK) {
                        namaMKExists = true
                    }
                }

                console.log(mahasiswaExists + "+"  + namaMKExists);

                if(mahasiswaExists && namaMKExists) {
                    Swal.fire({
                        title: 'Error!',
                        text: "Data Nilai of this student is already exists",
                        icon: 'error',
                        confirmButtonText: 'Cool'
                    }).then((res) => {
                        if(res.isConfirmed) {
                            $('#formInputNilai')[0].reset() // Mengosongkan inputan pada form
                            $('#modal').addClass('hidden')
                        }
                    })
                    return
                }

                $.ajax({
                    url: "process/tambah_nilai_process.php",
                    type: "POST",
                    dataType: "json",
                    data: formData,
                    success: function(res) {
                        console.log(res);

                        if(res.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: "Data added successfully!",
                                icon: 'success',
                                confirmButtonText: 'Cool',
                            }).then((res) => {
                                if(res.isConfirmed) {
                                    $('#modal').addClass('hidden')
                                    location.reload()
                                }
                            })
                            $('#formInputNilai')[0].reset() // Mengosongkan inputan pada form
                        }
                    },
                    error: function(error) {
                        console.log(error);
                        Swal.fire({
                            title: 'Success!',
                            text: "Failed to save data! " + error,
                            icon: 'success',
                            confirmButtonText: 'Cool'
                        })
                    }
                })
            })

            $('body').on('click', '#triggerEdit', function(e) {
                e.preventDefault()

                scrollTo(0, 0)

                var namaMK = "<?= htmlentities(urldecode($_SERVER['QUERY_STRING'])) ?>";
                    namaMahasiswa = $(this).attr('data-id');

                $.ajax({
                    url: "process/edit_nilai_process.php",
                    type: "GET",
                    data: {
                        'namaMahasiswa': namaMahasiswa,
                        'namaMK': namaMK
                    },
                    success: function(res) {
                        console.log(JSON.parse(res));

                        var resParse = JSON.parse(res)

                        if(resParse.success) {
                            $('#namaMahasiswaEdit').val(name)
                            $('#namaMKEdit').val(namaMK)
                            $('#dosenPengajarEdit').val("<?= $_SESSION['name'] ?>")
                            $('#nilaiKehadiranEdit').val(resParse.data.nilaiKehadiran)
                            $('#nilaiTugasEdit').val(resParse.data.nilaiTugas)
                            $('#nilaiUTSEdit').val(resParse.data.nilaiUTS)
                            $('#nilaiUASEdit').val(resParse.data.nilaiUAS)
                            document.body.classList.add('overflow-hidden')
                            $('#modalEdit').removeClass('hidden')
                        } else {
                            Swal.fire({
                                icon: 'error',
                                text: 'Data nilai not exists!'
                            })
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }
                })
            })

            $('body').on('submit', '#formEdit', function(e) {
                e.preventDefault()

                var formData = {
                    namaMahasiswa : namaMahasiswa,
                    namaMK : $('#namaMKEdit').val(),
                    dosenPengajar : "<?= $_SESSION['username'] ?>",
                    nilaiKehadiran : $('#nilaiKehadiranEdit').val(),
                    nilaiTugas : $('#nilaiTugasEdit').val(),
                    nilaiUTS : $('#nilaiUTSEdit').val(),
                    nilaiUAS : $('#nilaiUASEdit').val(),
                }

                $.ajax({
                    url: "process/update_nilai_process.php",
                    type: "POST",
                    data: formData,
                    success: function(res) {
                         // console.log(res);
                        var resParse = JSON.parse(res)

                        if(resParse.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: "Data updated successfully!",
                                icon: 'success',
                                confirmButtonText: 'Cool'
                            }).then((res) => {
                                if(res.isConfirmed) {
                                    $('#modalEdit').addClass('hidden')
                                    location.reload()
                                }
                            })
                            $('#formEdit')[0].reset() // Mengosongkan inputan pada form
                        }
                    },
                    error: function(error) {
                        console.log(error);
                    }
                })
            })
        })

    </script>
</body>
</html>